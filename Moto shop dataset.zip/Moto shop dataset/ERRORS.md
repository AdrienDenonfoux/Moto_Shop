# Anomalies injectées

## clients
- CUST0005: first_name with spaces and lowercase
- CUST0010: last_name in uppercase
- CUST0013: city lowercase
- CUST0016: city uppercase + trailing space
- CUST0019: city misspelled (Marseille)
- CUST0022: invalid email (no TLD)
- CUST0025: invalid email (no @)
- CUST0028: missing email
- CUST0031: date in dd/MM/yyyy format
- CUST0034: missing signup_date
- CUST0037: signup_date in the future
- CUST0040: missing city
- CUST0043: email uppercase
- CUST0050: exact duplicate row
- CUST0061: duplicate id with different city

## produits
- PROD003: category lowercase
- PROD008: category in French ('Gant' instead of Gloves)
- PROD012: sale_price as string with comma decimal
- PROD015: purchase_cost null
- PROD019: purchase_cost > sale_price
- PROD022: negative sale_price
- PROD026: brand lowercase + trailing space
- PROD030: brand uppercase
- PROD034: category field missing
- PROD041: duplicate product

## commandes
- ORD00011: unknown customer_id
- ORD00021: missing customer_id
- ORD00031: customer_id lowercase
- ORD00041: date dd/MM/yyyy
- ORD00051: impossible date (month 13)
- ORD00061: missing order_date
- ORD00071: status lowercase
- ORD00081: status in French
- ORD00091: missing status
- ORD00101: order_date in the future
- ORD00201: exact duplicate row

## lignes_commandes
- LINE000016: unknown product_id
- LINE000116: unknown product_id
- LINE000026: unknown order_id
- LINE000036: quantity = 0
- LINE000046: negative quantity
- LINE000056: missing quantity
- LINE000066: missing unit price
- LINE000076: negative unit price
- LINE000086: price with comma decimal
- LINE000096: price x100 (outlier, likely cents)
- LINE000106: abnormal quantity (50)
- LINE000301: exact duplicate row

