import csv, json, random, datetime as dt
random.seed(42)
first=["Lucas","Hugo","Louis","Gabriel","Arthur","Jules","Adam","Raphael","Paul","Nathan","Emma","Jade","Louise","Alice","Chloe","Lina","Lea","Manon","Camille","Sarah","Thomas","Antoine","Maxime","Julien","Nicolas","Pierre","Marie","Julie","Laura","Pauline"]
last=["Martin","Bernard","Dubois","Thomas","Robert","Richard","Petit","Durand","Leroy","Moreau","Simon","Laurent","Lefebvre","Michel","Garcia","David","Bertrand","Roux","Vincent","Fournier","Morel","Girard","Andre","Mercier","Dupont","Lambert","Bonnet","Francois","Martinez","Legrand"]
cities=[("Paris",18),("Marseille",8),("Lyon",8),("Toulouse",6),("Nice",5),("Nantes",5),("Montpellier",5),("Strasbourg",4),("Bordeaux",5),("Lille",5),("Rennes",4),("Reims",2),("Toulon",3),("Grenoble",3),("Dijon",2),("Angers",2),("Villejuif",2),("Clermont-Ferrand",2),("Le Mans",2),("Aix-en-Provence",3)]
cn=[c for c,_ in cities]; cw=[w for _,w in cities]
def strip(s): return s.lower().replace("ç","c").replace("é","e")
clients=[]
for i in range(1,101):
    f,l=random.choice(first),random.choice(last)
    d=dt.date(2021,1,1)+dt.timedelta(days=random.randint(0,1400))
    clients.append([f"CUST{i:04d}",f,l,random.choices(cn,cw)[0],f"{strip(f)}.{strip(l)}{random.randint(1,99)}@{random.choice(['gmail.com','yahoo.fr','orange.fr','outlook.fr','free.fr'])}",d.isoformat()])
errs={}
def err(table,key,desc): errs.setdefault(table,[]).append(f"{key}: {desc}")
# client errors
clients[4][1]="  hugo "; err("clients","CUST0005","first_name with spaces and lowercase")
clients[9][2]="DUBOIS"; err("clients","CUST0010","last_name in uppercase")
clients[12][3]="paris"; err("clients","CUST0013","city lowercase")
clients[15][3]="PARIS "; err("clients","CUST0016","city uppercase + trailing space")
clients[18][3]="Marseile"; err("clients","CUST0019","city misspelled (Marseille)")
clients[21][4]="julie.morel@gmail"; err("clients","CUST0022","invalid email (no TLD)")
clients[24][4]="paul.girardgmail.com"; err("clients","CUST0025","invalid email (no @)")
clients[27][4]=""; err("clients","CUST0028","missing email")
d=dt.date.fromisoformat(clients[30][5]); clients[30][5]=d.strftime("%d/%m/%Y"); err("clients","CUST0031","date in dd/MM/yyyy format")
clients[33][5]=""; err("clients","CUST0034","missing signup_date")
clients[36][5]="2027-03-15"; err("clients","CUST0037","signup_date in the future")
clients[39][3]=""; err("clients","CUST0040","missing city")
clients[42][4]=clients[42][4].upper(); err("clients","CUST0043","email uppercase")
clients.append(list(clients[49])); err("clients","CUST0050","exact duplicate row")
clients.append(["CUST0061"]+clients[60][1:3]+["Lyon",clients[60][4],clients[60][5]]); err("clients","CUST0061","duplicate id with different city")
with open("clients.csv","w",newline="",encoding="utf-8") as fh:
    w=csv.writer(fh,delimiter=";"); w.writerow(["customer_id","first_name","last_name","city","email","signup_date"]); w.writerows(clients)
# products: (category, base price range, popularity weight)
cats={"Helmet":((150,900),1.0),"Gloves":((30,250),2.2),"Leather Jacket":((350,1200),0.35),"Textile Jacket":((150,600),0.7),"Leather Pants":((300,800),0.15),"Textile Pants":((120,400),0.4),"Boots":((180,500),0.4),"Riding Shoes":((110,250),0.6),"Neck Warmer":((15,45),1.3),"Back Protector":((60,220),0.5),"Airbag Vest":((450,800),0.12),"Rain Suit":((40,120),0.6),"Intercom":((150,350),0.4),"Visor":((40,120),0.5)}
brands={"Dainese":(1.35,1.3),"Alpinestars":(1.3,1.3),"Shoei":(1.5,0.9),"Arai":(1.6,0.6),"Rev'It":(1.2,0.9),"Furygan":(0.95,1.1),"Ixon":(0.8,1.2),"Bering":(0.85,0.9),"Segura":(0.85,0.7),"Shark":(0.9,1.1),"HJC":(0.75,1.0),"Scorpion":(0.8,0.8),"Dexter":(0.55,1.4),"Sena":(1.0,1.0),"Cardo":(1.1,0.8),"In&motion":(1.0,0.6)}
catbrands={"Helmet":["Shoei","Arai","Shark","HJC","Scorpion","Dexter"],"Gloves":["Dainese","Alpinestars","Furygan","Ixon","Bering","Dexter","Rev'It"],"Leather Jacket":["Dainese","Alpinestars","Furygan","Segura","Rev'It"],"Textile Jacket":["Dainese","Alpinestars","Ixon","Bering","Rev'It","Dexter"],"Leather Pants":["Dainese","Alpinestars","Furygan"],"Textile Pants":["Dainese","Ixon","Bering","Rev'It","Dexter"],"Boots":["Dainese","Alpinestars","Furygan","Ixon"],"Riding Shoes":["Dainese","Alpinestars","Furygan","Segura","Dexter"],"Neck Warmer":["Dainese","Alpinestars","Ixon","Dexter","Bering"],"Back Protector":["Dainese","Alpinestars","Furygan"],"Airbag Vest":["Dainese","Alpinestars","In&motion"],"Rain Suit":["Ixon","Bering","Dexter"],"Intercom":["Sena","Cardo"],"Visor":["Shoei","Arai","Shark","HJC"]}
models=["Pro","Sport","Touring","Urban","Racing","Evo","Air","Classic","WP","Max"]
products=[];pid=1;pw={}
for c,brs in catbrands.items():
    for b in brs:
        for _ in range(random.choice([1,1,2])):
            lo,hi=cats[c][0]; m=brands[b][0]
            price=round(random.uniform(lo,lo+(hi-lo)*0.5)*m,0)-0.01
            margin=random.uniform(0.35,0.5) if b not in("Dexter",) else random.uniform(0.45,0.6)
            p={"product_id":f"PROD{pid:03d}","product_name":f"{b} {random.choice(models)} {c}","brand":b,"category":c,"sale_price":round(price,2),"purchase_cost":round(price*(1-margin),2)}
            products.append(p); pw[p["product_id"]]=cats[c][1]*brands[b][1]*random.uniform(0.6,1.4); pid+=1
P={p["product_id"]:p for p in products}
# product errors
products[2]["category"]="helmet"; err("produits","PROD003","category lowercase")
products[7]["category"]="Gant"; err("produits","PROD008","category in French ('Gant' instead of Gloves)")
products[11]["sale_price"]="189,99"; err("produits","PROD012","sale_price as string with comma decimal")
products[14]["purchase_cost"]=None; err("produits","PROD015","purchase_cost null")
x=products[18]; x["purchase_cost"]=round(x["sale_price"]*1.1,2); err("produits","PROD019","purchase_cost > sale_price")
products[21]["sale_price"]=-abs(products[21]["sale_price"]); err("produits","PROD022","negative sale_price")
products[25]["brand"]="alpinestars "; err("produits","PROD026","brand lowercase + trailing space")
products[29]["brand"]="DAINESE"; err("produits","PROD030","brand uppercase")
del products[33]["category"]; err("produits","PROD034","category field missing")
products.append(dict(products[40])); err("produits","PROD041","duplicate product")
with open("produits.json","w",encoding="utf-8") as fh: json.dump(products,fh,indent=2,ensure_ascii=False)
# orders: seasonality (spring peak, winter low)
season={1:0.5,2:0.6,3:1.1,4:1.4,5:1.5,6:1.4,7:1.1,8:0.8,9:1.2,10:1.0,11:1.1,12:1.3}
days=[dt.date(2024,1,1)+dt.timedelta(d) for d in range(730)]
dw=[season[d.month]*(1.4 if d.weekday()==5 else 1) for d in days]
cust_ids=[c[0] for c in clients[:100]]; custw=[random.paretovariate(1.5) for _ in cust_ids]
orders=[];lines=[];lid=1
ids=list(pw);w=list(pw.values())
for i in range(1,1201):
    d=random.choices(days,dw)[0]; st=random.choices(["DELIVERED","SHIPPED","CANCELLED","RETURNED","PENDING"],[80,6,7,4,3])[0]
    if d>dt.date(2025,12,15) and st=="DELIVERED": st=random.choice(["DELIVERED","SHIPPED"])
    oid=f"ORD{i:05d}"; orders.append([oid,random.choices(cust_ids,custw)[0],d.isoformat(),st])
    chosen=set()
    for _ in range(random.choices([1,2,3,4,5],[45,28,15,8,4])[0]):
        p=random.choices(ids,w)[0]
        if p in chosen: continue
        chosen.add(p); cat=P[p].get("category","Helmet")
        q=random.choices([1,2,3],[70,22,8])[0] if cat in("Gloves","Neck Warmer","Visor") else random.choices([1,2],[95,5])[0]
        base=P[p]["sale_price"] if isinstance(P[p]["sale_price"],float) and P[p]["sale_price"]>0 else 189.99
        disc=random.choices([0,0.1,0.15,0.2,0.3],[70,12,8,6,4])[0]
        if d.month in(1,7) : disc=max(disc,random.choice([0,0.2,0.3]))
        lines.append([f"LINE{lid:06d}",oid,p,q,round(abs(base)*(1-disc),2)]); lid+=1
# order errors
def setf(i,j,v,desc): orders[i][j]=v; err("commandes",orders[i][0],desc)
setf(10,1,"CUST0999","unknown customer_id")
setf(20,1,"","missing customer_id")
setf(30,1,"cust0012","customer_id lowercase")
setf(40,2,dt.date.fromisoformat(orders[40][2]).strftime("%d/%m/%Y"),"date dd/MM/yyyy")
setf(50,2,"2024-13-05","impossible date (month 13)")
setf(60,2,"","missing order_date")
setf(70,3,"delivered","status lowercase")
setf(80,3,"Livrée","status in French")
setf(90,3,"","missing status")
setf(100,2,"2028-01-10","order_date in the future")
orders.append(list(orders[200])); err("commandes",orders[200][0],"exact duplicate row")
with open("commandes.csv","w",newline="",encoding="utf-8") as fh:
    wr=csv.writer(fh,delimiter=";"); wr.writerow(["order_id","customer_id","order_date","status"]); wr.writerows(orders)
# line errors
def setl(i,j,v,desc): lines[i][j]=v; err("lignes_commandes",lines[i][0],desc)
setl(15,2,"PROD999","unknown product_id"); setl(115,2,"PROD777","unknown product_id")
setl(25,1,"ORD99999","unknown order_id")
setl(35,3,0,"quantity = 0"); setl(45,3,-2,"negative quantity"); setl(55,3,"","missing quantity")
setl(65,4,"","missing unit price"); setl(75,4,-49.99,"negative unit price")
setl(85,4,str(lines[85][4]).replace(".",","),"price with comma decimal")
setl(95,4,lines[95][4]*100,"price x100 (outlier, likely cents)")
setl(105,3,50,"abnormal quantity (50)")
lines.append(list(lines[300])); err("lignes_commandes",lines[300][0],"exact duplicate row")
with open("lignes_commandes.csv","w",newline="",encoding="utf-8") as fh:
    wr=csv.writer(fh,delimiter=";"); wr.writerow(["line_id","order_id","product_id","quantity","unit_price_charged"]); wr.writerows(lines)
with open("ERRORS.md","w",encoding="utf-8") as fh:
    fh.write("# Anomalies injectées\n\n")
    for t,l in errs.items(): fh.write(f"## {t}\n"+"".join(f"- {x}\n" for x in l)+"\n")
print(len(clients),len(products),len(orders),len(lines))
