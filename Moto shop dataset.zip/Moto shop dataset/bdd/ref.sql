
CREATE SCHEMA IF NOT EXISTS ref;

-- ***************** CUSTOMERS ****************************

-- Référentiel des villes : clé normalisée -> nom officiel
CREATE TABLE ref.city_alias (
  alias_key     VARCHAR(150) PRIMARY KEY,
  city_name     VARCHAR(150) NOT NULL,
  is_correction BOOLEAN      NOT NULL DEFAULT false
);

INSERT INTO ref.city_alias (alias_key, city_name)
SELECT lower(c), c FROM unnest(ARRAY[
  'Paris','Marseille','Lyon','Toulouse','Nice','Nantes','Montpellier',
  'Strasbourg','Bordeaux','Lille','Rennes','Reims','Toulon','Grenoble',
  'Dijon','Angers','Villejuif','Clermont-Ferrand','Le Mans','Aix-en-Provence'
]) AS c;

INSERT INTO ref.city_alias VALUES ('marseile', 'Marseille', true);

-- ***************** PRODUCTS ****************************

-- Référentiel des marques
CREATE TABLE ref.brand_alias (
  alias_key  VARCHAR(100) PRIMARY KEY,
  brand_name VARCHAR(100) NOT NULL
);

INSERT INTO ref.brand_alias (alias_key, brand_name)
SELECT lower(b), b FROM unnest(ARRAY[
  'Dainese','Alpinestars','Dexter','Rev''It','Furygan','Ixon','Bering','HJC',
  'Segura','Arai','Shoei','Shark','Scorpion','In&motion','Sena','Cardo'
]) AS b;

-- Référentiel des catégories, avec des alias français
CREATE TABLE ref.category_alias (
  alias_key     VARCHAR(100) PRIMARY KEY,
  category_name VARCHAR(100) NOT NULL,
  is_correction BOOLEAN      NOT NULL DEFAULT false
);

INSERT INTO ref.category_alias (alias_key, category_name)
SELECT lower(c), c FROM unnest(ARRAY[
  'Helmet','Gloves','Leather Jacket','Textile Jacket','Leather Pants','Textile Pants',
  'Boots','Riding Shoes','Neck Warmer','Airbag Vest','Visor','Back Protector',
  'Rain Suit','Intercom'
]) AS c;

INSERT INTO ref.category_alias VALUES
  ('gant',   'Gloves', true),
  ('gants',  'Gloves', true),
  ('casque', 'Helmet', true),
  ('bottes', 'Boots',  true);
  
-- ***************** ORDERS ****************************


-- Référentiel des statuts, avec la règle de chiffre d'affaires centralisée
CREATE TABLE ref.status_alias (
  alias_key     VARCHAR(50) PRIMARY KEY,
  status_code   VARCHAR(20) NOT NULL,
  is_correction BOOLEAN     NOT NULL DEFAULT false,
  is_revenue    BOOLEAN     NOT NULL
);

INSERT INTO ref.status_alias VALUES
  ('delivered',  'DELIVERED', false, true),
  ('shipped',    'SHIPPED',   false, true),
  ('pending',    'PENDING',   false, false),
  ('cancelled',  'CANCELLED', false, false),
  ('returned',   'RETURNED',  false, false),
  ('livrée',     'DELIVERED', true,  true),
  ('livree',     'DELIVERED', true,  true),
  ('expédiée',   'SHIPPED',   true,  true),
  ('annulée',    'CANCELLED', true,  false),
  ('retournée',  'RETURNED',  true,  false),
  ('en attente', 'PENDING',   true,  false);

-- Droits pour Talend
GRANT USAGE ON SCHEMA ref TO talend_etl;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE
  ON ALL TABLES IN SCHEMA ref TO talend_etl;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA ref TO talend_etl;