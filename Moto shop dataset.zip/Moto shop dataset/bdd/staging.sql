-- Staging
CREATE ROLE talend_etl
WITH LOGIN
PASSWORD '*****';

GRANT CONNECT ON DATABASE motorcyclestore TO talend_etl;

GRANT USAGE ON SCHEMA stg TO talend_etl;

GRANT SELECT ON ALL TABLES IN SCHEMA stg
TO talend_etl;

ALTER DEFAULT PRIVILEGES IN SCHEMA stg
GRANT SELECT ON TABLES TO talend_etl;

GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE
  ON ALL TABLES IN SCHEMA stg TO talend_etl;

CREATE TABLE stg.customers_raw (
  batch_id          VARCHAR(20) NOT NULL,
  source_row_num    INTEGER     NOT NULL,
  customer_id       TEXT,
  first_name        TEXT,
  last_name         TEXT,
  city              TEXT,
  email             TEXT,
  registration_date TEXT,
  loaded_at         TIMESTAMP   NOT NULL
);

CREATE TABLE stg.products_raw (
  batch_id          VARCHAR(20) NOT NULL,
  source_row_num    INTEGER     NOT NULL,
  product_reference TEXT,
  product_name      TEXT,
  brand             TEXT,
  category          TEXT,
  sale_price        TEXT,
  purchase_cost     TEXT,
  loaded_at         TIMESTAMP   NOT NULL
);

CREATE TABLE stg.orders_raw (
  batch_id       VARCHAR(20) NOT NULL,
  source_row_num INTEGER     NOT NULL,
  order_id       TEXT,
  customer_id    TEXT,
  order_date     TEXT,
  status         TEXT,
  loaded_at      TIMESTAMP   NOT NULL
);

CREATE TABLE stg.order_lines_raw (
  batch_id          VARCHAR(20) NOT NULL,
  source_row_num    INTEGER     NOT NULL,
  line_id           TEXT,
  order_id          TEXT,
  product_reference TEXT,
  quantity          TEXT,
  actual_unit_price TEXT,
  loaded_at         TIMESTAMP   NOT NULL
);