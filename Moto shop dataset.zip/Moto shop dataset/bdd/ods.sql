-- Operational Data Store
CREATE SCHEMA IF NOT EXISTS ods;

-- Produits corrigés
CREATE TABLE ods.products (
  product_id     VARCHAR(10)   PRIMARY KEY,
  product_name   VARCHAR(255),
  brand          VARCHAR(100),
  category       VARCHAR(100),
  sale_price     NUMERIC(10,2),
  purchase_cost  NUMERIC(10,2),
  batch_id       VARCHAR(20)   NOT NULL,
  source_row_num INTEGER       NOT NULL,
  loaded_at      TIMESTAMP     NOT NULL
);


-- Clients corrigés
CREATE TABLE ods.customers (
  customer_id    VARCHAR(10)  PRIMARY KEY,
  first_name     VARCHAR(100),
  last_name      VARCHAR(100),
  city           VARCHAR(150),
  email          VARCHAR(255),
  signup_date    DATE,
  batch_id       VARCHAR(20)  NOT NULL,
  source_row_num INTEGER      NOT NULL,
  loaded_at      TIMESTAMP    NOT NULL
);

-- Commandes corrigées
CREATE TABLE ods.orders (
  order_id       VARCHAR(10) PRIMARY KEY,
  customer_id    VARCHAR(10) NOT NULL,
  order_date     DATE        NOT NULL,
  status         VARCHAR(20),
  batch_id       VARCHAR(20) NOT NULL,
  source_row_num INTEGER     NOT NULL,
  loaded_at      TIMESTAMP   NOT NULL
);

-- Ligne de commande corrigées
CREATE TABLE ods.order_lines (
  line_id            VARCHAR(12)   PRIMARY KEY,
  order_id           VARCHAR(10)   NOT NULL,
  product_id         VARCHAR(10)   NOT NULL,
  quantity           INTEGER       NOT NULL CHECK (quantity > 0),
  unit_price_charged NUMERIC(10,2) NOT NULL CHECK (unit_price_charged > 0),
  batch_id           VARCHAR(20)   NOT NULL,
  source_row_num     INTEGER       NOT NULL,
  loaded_at          TIMESTAMP     NOT NULL
);


-- Droits pour Talend
GRANT USAGE ON SCHEMA ods TO talend_etl;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE
  ON ALL TABLES IN SCHEMA ods TO talend_etl;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA ods TO talend_etl;