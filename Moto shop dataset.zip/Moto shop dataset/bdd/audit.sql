CREATE SCHEMA IF NOT EXISTS audit;


-- Rejets et avertissements, pour toutes les sources
CREATE TABLE audit.dq_issues (
  issue_id       SERIAL       PRIMARY KEY,
  batch_id       VARCHAR(20)  NOT NULL,
  job_name       VARCHAR(100) NOT NULL,
  source_table   VARCHAR(50)  NOT NULL,
  source_row_num INTEGER,
  business_key   VARCHAR(50),
  severity       VARCHAR(10)  NOT NULL,  -- 'REJECT' ou 'WARNING'
  rule_code      VARCHAR(50)  NOT NULL,
  raw_values     TEXT,
  detected_at    TIMESTAMP    NOT NULL DEFAULT now()
);

-- Journal des exécutions
CREATE TABLE audit.job_runs (
  run_id        SERIAL       PRIMARY KEY,
  batch_id      VARCHAR(20)  NOT NULL UNIQUE,
  job_name      VARCHAR(100) NOT NULL,
  status        VARCHAR(10)  NOT NULL,   -- RUNNING, SUCCESS, FAILED
  started_at    TIMESTAMP    NOT NULL,
  ended_at      TIMESTAMP,
  duration_sec  INTEGER,
  stg_rows      INTEGER,
  ods_rows      INTEGER,
  rejected_rows INTEGER,
  warnings      INTEGER,
  error_message TEXT
);

-- La réconciliation devient une vue, limitée au batch courant
CREATE OR REPLACE VIEW audit.v_reconciliation AS
WITH cur AS (SELECT DISTINCT batch_id FROM stg.customers_raw),
s AS (
  SELECT 'customers_raw' AS source_table, COUNT(*) AS stg_rows FROM stg.customers_raw
  UNION ALL SELECT 'products_raw',    COUNT(*) FROM stg.products_raw
  UNION ALL SELECT 'orders_raw',      COUNT(*) FROM stg.orders_raw
  UNION ALL SELECT 'order_lines_raw', COUNT(*) FROM stg.order_lines_raw
),
o AS (
  SELECT 'customers_raw' AS source_table, COUNT(*) AS ods_rows FROM ods.customers
  UNION ALL SELECT 'products_raw',    COUNT(*) FROM ods.products
  UNION ALL SELECT 'orders_raw',      COUNT(*) FROM ods.orders
  UNION ALL SELECT 'order_lines_raw', COUNT(*) FROM ods.order_lines
),
r AS (
  SELECT source_table, COUNT(DISTINCT source_row_num) AS rejected_rows
  FROM audit.dq_issues
  WHERE severity = 'REJECT' AND batch_id IN (SELECT batch_id FROM cur)
  GROUP BY source_table
),
w AS (
  SELECT source_table, COUNT(*) AS warnings
  FROM audit.dq_issues
  WHERE severity = 'WARNING' AND batch_id IN (SELECT batch_id FROM cur)
  GROUP BY source_table
)
SELECT s.source_table, s.stg_rows, o.ods_rows,
       COALESCE(r.rejected_rows, 0) AS rejected_rows,
       COALESCE(w.warnings, 0)      AS warnings,
       s.stg_rows - o.ods_rows - COALESCE(r.rejected_rows, 0) AS gap
FROM s
JOIN o USING (source_table)
LEFT JOIN r USING (source_table)
LEFT JOIN w USING (source_table);



-- Droits pour Talend
GRANT USAGE ON SCHEMA audit TO talend_etl;
GRANT SELECT, INSERT, UPDATE, DELETE, TRUNCATE
  ON ALL TABLES IN SCHEMA audit TO talend_etl;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA audit TO talend_etl;