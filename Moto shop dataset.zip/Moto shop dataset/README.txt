Réalisme des données
Prix : Dainese, Alpinestars, Arai et Shoei sont environ 30 à 60 % plus chers. Dexter est la marque la moins chère et celle qui a la meilleure marge.
Volumes : les gants sont de loin les plus vendus (environ 1 200 unités). Viennent ensuite les tours de cou (environ 360) et les blousons textile. Le pantalon cuir n'en compte qu'environ 14 et le gilet airbag environ 15.
Catégories ajoutées : protection dorsale, gilet airbag, combinaison de pluie, intercom (Sena et Cardo) et écran de casque.
Saisonnalité : les ventes culminent au printemps, avec plus de commandes le samedi. On trouve aussi des remises en janvier et en juillet, ce qui crée des écarts entre le prix catalogue et le prix facturé.
Clients : quelques clients fidèles passent beaucoup de commandes
Statuts : environ 80 % des commandes sont livrées, environ 7 % annulées et environ 4 % retournées.

Erreurs à nettoyer
Clients : espaces en trop, majuscules et minuscules mélangées, faute de frappe (« Marseile »), emails invalides ou absents, date au format dd/MM/yyyy, date dans le futur, doublon exact et même identifiant avec une ville différente.
Produits : catégorie en français (« Gant ») ou en minuscules, catégorie absente, prix sous forme de texte avec une virgule, prix négatif, coût d'achat absent ou supérieur au prix de vente, marque mal formatée et doublon.
Commandes : client inconnu ou absent, date impossible (mois 13), date absente ou dans le futur, statut en français ou absent, doublon.
Lignes : produit ou commande inconnus, quantité nulle, négative, absente ou anormale (50), prix absent ou négatif, prix avec une virgule, prix multiplié par 100 et doublon.

Schéma	Contenu	Exemple de table
stg	: Données brutes, tout en texte	stg.customers_raw
ods	: Données corrigées, une table par source	ods.customers
audit :	Lignes rejetées ou douteuses, avec leur motif	audit.rejects
dwh	: Tables d'analyse	dwh.dim_customer, dwh.fact_sales
